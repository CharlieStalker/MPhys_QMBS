Figures for Chapter 2
=====================

This folder should contain the figure files for Chapter 2 Figures