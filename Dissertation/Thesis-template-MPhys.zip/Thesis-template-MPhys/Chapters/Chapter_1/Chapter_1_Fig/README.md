Figures for Chapter 1
=====================

This folder should contain the figure files for Chapter 1 Figures